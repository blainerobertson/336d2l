<?php include 'view/header.php'; ?>
<main>
        <!--Add a link to the product registration application-->
    <h2>Customers</h2>
    <ul>
        <li><a href="">Register Product</a></li>
    </ul>

</main>
<?php include 'view/footer.php'; ?>