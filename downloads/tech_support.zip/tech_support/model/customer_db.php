<?php
// Needed: a function to get a customer by their email address
function get_customer_by_email($email) {
    global $db;
    
}