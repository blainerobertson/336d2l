<?php

// Get all the products for the registration dropdown list
function get_products() {

}
