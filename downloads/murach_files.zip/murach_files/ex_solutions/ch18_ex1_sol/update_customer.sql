UPDATE customers
SET password = '5e5ame'
WHERE emailAddress = 'johnsmith@example.com'