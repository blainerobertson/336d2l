<!DOCTYPE html>
<html>
    
    <!-- the head section -->
    <head>
        <title>Exercise</title>
        <link rel="stylesheet" type="text/css"
              href="<?php echo $app_path ?>main.css" />
    </head>

    <!-- the body section -->
    <body>
