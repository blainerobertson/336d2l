<!DOCTYPE html>
<html>
<!-- the head section -->
<head>
    <title>My Guitar Shop</title>
    <link rel="stylesheet" type="text/css"
          href="/book_apps/ch05_guitar_shop/main.css">
</head>

<!-- the body section -->
<body>
<header><h1>My Guitar Shop</h1></header>
