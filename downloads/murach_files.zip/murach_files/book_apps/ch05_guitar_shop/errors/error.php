<?php include '../view/header.php'; ?>
<main>
    <h1>Error</h1>
    <p class="first_paragraph"><?php echo $error; ?></p>
</main>
<?php include '../view/footer.php'; ?>