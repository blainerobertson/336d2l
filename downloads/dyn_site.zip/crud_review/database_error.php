<!DOCTYPE html>
<html>

<head>
	<meta charset="UTF-8">
	<title>Home | Ch. 4 Revisited</title>
	<link href="style.css" rel="stylesheet" type="text/css">
</head>

<body>
	<header>
		<h1>Ch. 4 Revisited</h1>
		<div id="tools"><a href="registration.php" title="Go to the registration page">Register</a> </div>
	</header>

	<main>
		<h1>Database Error</h1>
		<p>There was an error connecting to the database.</p>
	</main>

	<footer>
		<small>For review only</small>
	</footer>
</body>

</html>
