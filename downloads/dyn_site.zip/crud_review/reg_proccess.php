<?php
// Get your database connection

// Determine if the registration form has been submitted
// If so, process the data
// If not, send the site visitor back to the registration.php file
if (filter_input(INPUT_POST, 'submit') === 'Register') {

// Capture and filter the inputs



// Check the values, return if errors are found
  $error = []; // an empty array to store errors into

// Check for errors, if found redirect to the
// registration.php page for repair and resubmission
  if (!empty($error)) {
    include 'registration.php';
    exit;
  }

// Use a prepared statement to write the data to the visitors.registration table


// Test if the insertion worked, if yes display a confirmation, if not show a failure message


} else {
  // Redirect to the registration page if the registration form
  // was not submitted and the data sent to this page
  header('location: registration.php');
  exit;
}
?>
<!doctype html>
<html>

    <head>
        <meta charset="UTF-8">
        <title>Registration Result | Ch. 4 Revisited</title>
        <link href="style.css" rel="stylesheet" type="text/css">
    </head>

    <body>
        <header>
            <h1>Ch. 4 Revisited</h1>
            <div id="tools"><a href="registration.php" title="Go to the registration page">Register</a> </div>
        </header>
        <main>
            <?php
           // Display the insertion message here

            ?>
        </main>
        <footer>
            <small>For review only</small>
        </footer>
    </body>

</html>
