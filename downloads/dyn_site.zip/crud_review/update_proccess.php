<?php
// Get your database connection

// Determine if an update request has started
// If so, retrieve the data from the database to be edited
// If not, send the site visitor back to the index.php file
if (filter_input(INPUT_GET, 'id')) {

// Capture the data key that should have been sent



// If the key has no value, set an error message for display in this page
  if () {
    
  }

// If data key is present, use a prepared statement to select the 
// related data from the visitors.registration table


// Test if a recordset of data was returned,
// if not, set an error message
// if yes jump to the main element and display the data in a form for editing
  if () {
   
  }
} else {
  // Redirect to the index.php page if the visitor comes to 
  // this page without first triggering an update
  header('location: index.php');
  exit;
}
?>
<!doctype html>
<html>

    <head>
        <meta charset="UTF-8">
        <title>Update Content | Ch. 4 Revisited</title>
        <link href="style.css" rel="stylesheet" type="text/css">
    </head>

    <body>
        <header>
            <h1>Ch. 4 Revisited</h1>
            <div id="tools"><a href="registration.php" title="Go to the registration page">Register</a> </div>
        </header>
        <main>
            <?php  ?>
            <form action="update_confirm.php" method="post">
			<fieldset>
				<label for="firstName">First Name</label>
                <input type="text" name="firstName" id="firstName" value="">
				<label for="lastName">Last Name</label>
                <input type="text" name="lastName" id="lastName" value="">
				<label for="email">Email</label>
                <input type="email" name="email" id="email" value="">
				<label>&nbsp;</label>
				<input type="submit" name="submit" value="Update">
                <input type="hidden" name="id" id="id" value="">
			</fieldset>
		</form>
        </main>
        <footer>
            <small>For review only</small>
        </footer>
    </body>

</html>
