<?php
// Get the DB connection


// Get all registered users from the visitors.registration table


// If there are registered users display them in the main element below


// If there are no registered users, display the 'Nothing to see here paragraph'


?>
<!doctype html>
<html>

<head>
	<meta charset="UTF-8">
	<title>Home | Ch. 4 Revisited</title>
	<link href="style.css" rel="stylesheet" type="text/css">
</head>

<body>
	<header>
		<h1>Ch. 4 Revisited</h1>
		<div id="tools"><a href="registration.php" title="Go to the registration page">Register</a> </div>
	</header>
	<main>
		<h1>Home Page</h1>
		<p>Nothing to see here. Why don't your register?</p>
	</main>
	<footer>
		<small>For review only</small>
	</footer>
</body>

</html>
