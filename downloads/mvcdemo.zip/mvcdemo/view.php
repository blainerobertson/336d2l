<!DOCTYPE html>
<!--
This is the view. It provides all human interaction's
for the application.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>View</title>
        <style>
            label, input{
                display: block;
            }
            .notify{
                font-weight: 700;
                color: red;
                background-color: yellow;
            }
            #page-nav ul{
                list-style: none;
            }
        </style>
    </head>
    <body>
        <header id="page-header">
            <h1>CIT 336 Demo</h1>
        </header>
        <nav id="page-nav">
            <ul>
                <li><a href="/" title="Go to home page">Home</a></li>
            </ul>
        </nav>
        <main>
            <?php
            if(isset($message)){
                echo '<p class="notify">'.$message.'</p>';
            }
            if(isset($categoryList)){
                $output = '<h2>Existing Categories</h2>';
                $output .= '<ul>';
                foreach ($categoryList as $category) {
                    $output .= '<li>'.$category['categoryName'].'</li>';
                }
                $output .= '</ul>';
                // A single point of display
                echo $output;
            }
            ?>
            <h2>Add a New Category</h2>
            <form method="post" action=".">
                <fieldset>
                    <label for="addCategory">Category Name:</label>
                    <input name="addCategory" id="addCategory">
                    <label>&nbsp;</label>
                    <input type="submit" name="action" value="Add Category">
                </fieldset>
            </form>
        </main>
        <footer id="page-footer">
            <p>&COPY; CIT 336 Demo</p>
        </footer>
    </body>
</html>
