<?php
/* 
 * This is the controller
 * It holds all application logic (decision making)
 * controls the flow (when other assets are used)
 * receives all inputs from views
 * sends all results (in views) back to the browser
 */

// Bring the model (and its functions) into scope
require_once 'model.php';

// See if the form has been submitted
if(filter_input(INPUT_POST, 'action')){
    // Get the input
    $newCategory = filter_input(INPUT_POST, 'addCategory');
    // Check for a value after filtering
    if(empty($newCategory)){
        // No value found, send back to be fixed
        $message = 'The Category name cannot be empty. Please add a name.';
        include 'view.php';
        exit;
    } else {
        // Value is ok, add to database via the model
        $insertResult = addCategory($newCategory);
        if($insertResult){
            // The add worked, set a message
            $message = "The new category - $newCategory - was added.";
        } else {
            // The add failed, set a message
            $message = "Sorry, the new category submission failed.";
        }
        // Send the view back with a list of categories in the database
        $categoryList = getCategories(); 
        include 'view.php';
        exit;
    }
} else {
    include 'view.php';
    exit;
}