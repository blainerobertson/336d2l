<?php
/*
 * This is the model
 * It contains all functionality to interact with the database server
 * It nees access to the database connection to do its work
 */

require_once 'database.php';

function addCategory($newCategory) {
    global $db;
    $query = 'INSERT INTO categories (categoryName) VALUES (:newCategory)';
    $statement = $db->prepare($query);
    $statement->bindValue(':newCategory', $newCategory, PDO::PARAM_STR);
    $statement->execute();
    $insertResult = $statement->rowCount();
    $statement->closeCursor();
    return $insertResult;
}

// Get all categories
function getCategories() {
    global $db;
    $query = 'SELECT * FROM categories ORDER BY categoryID';
    $statement = $db->prepare($query);
    $statement->execute();
    $categories = $statement->fetchAll();
    $statement->closeCursor();
    return $categories;
}
